package com.google.code.gsonrmi.serializer;

/**
 * Created with IntelliJ IDEA.
 * User: cristi
 * Date: 8/9/13
 * Time: 1:34 PM
 * To change this template use File | Settings | File Templates.
 */