package ro.meditrack.exception;

/**
 * @author motan
 * @date 7/5/14
 */
public class GsonInstanceNullException extends Exception {
}
