package ro.meditrack;

/**
 * Created by motan on 5/17/14.
 */
public class Keys {
    public static int NOT_RECEIVED = 0;
}
