package ro.meditrack.model;

/**
 * @author motan
 * @date 7/9/14
 */
public interface ItemInterface {

    public String getItemDescription();
}
