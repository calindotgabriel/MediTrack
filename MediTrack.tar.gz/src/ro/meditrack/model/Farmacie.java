package ro.meditrack.model;

import java.io.Serializable;

/**
 * Pharmacy class model, used to store info about one entity.
 */
public class Farmacie  implements Serializable, ItemInterface{


    private int id;
    private String name;
    private String[] openHours;
    private String vicinity;
    private String phNumber;
    private String url;
    private int icon = - 1;
    private double lat = -1.0;
    private double lng = -1.0;
    private int compensat;
    private int openNow;


    public Farmacie() {

    }

    public String getName() {
        return name;
    }

    public boolean getOpenNow() {
        return openNow>0;
    }

    public void setOpenNow(int openNow) {
        this.openNow = openNow;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVicinity() {
        return vicinity;
    }

    public void setVicinity(String vicinity) {
        this.vicinity = vicinity;
    }

    public String getItemDescription() {
        return name;
    }

    public String[] getOpenHours() {
        return openHours;
    }

    public void setOpenHours(String[] openHours) {
        this.openHours = openHours;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public boolean isNonstop() {
        if (this.openHours[0].equals( "nonstop"))
            return true;
        if (this.openNow > 0)
            return true;
        return false;
    }


    public int getCompensat() {
        return compensat;
    }

    public void setCompensat(int compensat) {
        this.compensat = compensat;
    }


    public String getPhNumber() {
        return phNumber;
    }

    public void setPhNumber(String phNumber) {
        this.phNumber = phNumber;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }


}
